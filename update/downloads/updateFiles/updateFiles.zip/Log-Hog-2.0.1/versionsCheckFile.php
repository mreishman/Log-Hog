<?php

$versionCheckArray = array(
	'version'		=> '2.0.1',
	'versionList'		=> array(
		'2.0.1'	        => array(
			'branchName'	=> 'testUpdate',
			'releaseNotes'	=> '<ul><li>Test Update</li><ul>'
		)
	)
);
?>
